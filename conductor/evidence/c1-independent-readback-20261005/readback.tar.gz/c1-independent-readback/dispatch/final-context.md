# C1.4.evidence

Model: gpt-6-luna; output: Phase evidence reconciliation
Oracle: Every parent task has integrated output and executed gates; unresolved failures prevent acceptance

Instance: manual_readback_20261005 — User-authorized independent physical readback only: 666 files, exact physicalv2 schema/unit/null/payload checks and source accounting; C1.4 remains open.
Interface: conductor/design/calibration/c1-independent-readback-v1.md SHA9ca7b274409c39d3d114797ae6c1eb728af4fe6a1b1b31dc744d533b0de930cf; current joined file SHA bindings are fresh, historical source logs retained.


## conductor/design/calibration/c1-independent-readback-v1.md:1-52
# C1 independent normalized physical readback v1

Coordinator reviewed 5 October 2026 for the user's explicit manual readback.
Scope: direct second-implementation reads and accounting, not full C1.4,
clinical validity, source changes, dependency changes or release acceptance.
Parent base62a2866; accepted Kairos c441c693eccf666d00e2720a215dd1f238e331ad.

Use pinned PyArrow25.0.1 direct IPC file/stream and Parquet readers. Import no
production codec, encoder, decoder, Rust schema helper or C01 interop validator.
Declare independent expected physical-v2 types, field order/nullability and
schema/field metadata from frozen c1 physical schema v1/v2 contracts and C0
schema. Never infer expectations from observed files, cast or normalize away
mismatches. Read all648 C01 Rust outputs (24 layouts,3 tables,3 formats,3 writer
limits),9 Rust current-joined C1.2 outputs and9 retained C1.1 fixture files.
Bind each input file to accepted manifests/archive checksums before decoding.

Check fixed16-byte UTC signed little-endian i128, unit ns_since_unix_epoch,
against exact RFC3339 text using integer calendar arithmetic; ticks unsigned
little-endian u128, unit1ns, against UTC minus declared origin. No float timestamp
or native Arrow timestamp narrowing. Check UInt32 occurrence, UInt64 order,
canonical decimal UTF8 ranks, bools, lists, nested structs and enum/payload values
against the actual retained logical records. All clock precision/offset/lineage
values survive. UTC text remains exact, even with zero fractional digits beyond
nanosecond precision. Parent-null clocks do not expose child-buffer values.

presence_fields is sorted unique absent logical paths. Preserve absent vs
explicit null vs present empty values, including nullable clocks/actor/detail,
absent-only quality_flags/tick_resolution/rank/source_fields and empty required
cluster_ids. raw_time_values is non-null list of non-null key/value entry structs,
keys sorted unique, values nullable. Verify recursive nullability and report
observed null/missing/empty counts and all physical field types/metadata.

Reconcile each C01 profile separately: source/candidate/mapper-accepted/excluded/
failed/unresolved, validator valid+quarantine, outcome observed/not_censored/right
and validator window-censored cases. Long profiles7rows/7candidates/6mapper events/
1exclusion/2outcomes; wide3rows/9candidates/6events/3exclusions/2outcomes.
Quarantine partitions6mapper events into3valid+3quarantined. Each profile has
1observed and1right-censored outcome, zero window-censored cases. Distinct profile
totals are fixture totals:17rawrows,23candidates,18mapper events,5exclusions,
6outcomes including3right-censored. No double counting format/layout replicas.

Separately reconcile all51 C1.1 actual mapper requests, including classified
failures, against accepted snapshot SHA and manifest request membership. This
heterogeneous fixture collection is not one ingestion dataset/cohort. Verify
31trace events,17exclusions,4outcomes in physical replicas; reconcile actual
source/candidate/failed/unresolved and censor counts from snapshot before claim.

Reader-negative controls must detect an altered unit, wrong integer width/type,
null in required field, UTC-byte/text mismatch and censored event clock conflict,
while untouched actual data passes. Retain exact command/cwd/source/tool/input/
output hashes, per-file receipts and count tables. No new Rust execution needed:
this verifies retained actual artifacts. Preserve C1.4 and unrelated Q5.2 holds.


## conductor/evidence/c1-independent-readback-20261005/inspect_readback.py:1-27
#!/usr/bin/env python3
"""Independent direct PyArrow readback for retained C1 physical artifacts.

This verifier declares its schemas locally from the frozen physical-v1/v2
contracts. It deliberately does not import a repository encoder, decoder, or
schema builder. It reads accepted mapper/calibration artifacts without writing
to any input path.
"""
from __future__ import annotations

import argparse
import collections
import copy
import hashlib
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, NoReturn

import pyarrow as pa
import pyarrow.ipc as ipc
import pyarrow.parquet as pq

FORMAT = "careops.calibration.physical"
LOGICAL_SCHEMA_SHA256 = "8c46db62f691f243385a4ebdf8a7a3d3670e2655dd0c3f82cba4335ced2a3842"


## conductor/design/calibration/c1-physical-schema-v2.md:1-17
# C1 physical calibration schema v2

Status: experimental physical v2, locally qualified against full independently declared Rust schemas on Rust1.88/1.99 and PyArrow25.0.1 IPC file/stream and Parquet readers. Evidence is retained in `conductor/evidence/c1.2-typed-qualification-20261004/`. This supersedes the rejected v1 map layout; no stable release or clinical-feed acceptance.

## Compatibility decision

The v1 PyArrow MapType used a default internal `entries` field. Independent PyArrow25.0.1 Parquet readback renamed it `raw_time_values`, so exact schema equality with metadata failed. Type-only equality is insufficient. Version2 explicitly changes the physical map encoding; logical C0 calibration-v1 and its SHA remain unchanged. Admission requires metadata physical_version=2 and the full exact schema. Version1 files are rejected; no silent coercion or compatibility claim. A separately reviewed migration can validate/reconstruct C0 records using the retained v1 codec at commit23c0995, then encode v2. No v1 fixture collection was accepted.

## Frozen layout

Retain all v1 named columns, nullability, metadata and scalar encodings except `raw_time_values`. Its C0 logical string-to-nullable-string map becomes a non-null list with non-null `element` structs, each with non-null UTF8 `key` and nullable UTF8 `value`. Metadata declares encoding=sorted_unique_entries_v2. Keys are sorted and unique; empty maps are empty lists, null values stay null. Null/missing/extra entry fields, duplicate/unsorted keys and wrong scalar types reject. The list element name is explicitly `element` for compliant Parquet nesting. It is a typed map representation, without JSON or opaque serialized schema bytes.

UTC retains exact RFC3339 text and signed_i128_le fixed16 bytes with ns_since_unix_epoch; ticks use unsigned_u128_le fixed16 bytes with1ns. Calendar text supports Gregorian0001..9999 separately from full integer byte codecs. Arbitrary event ranks remain canonical decimal UTF8, source_order UInt64, occurrence UInt32. Optional absence markers distinguish absent/null/empty; raw_event.source_fields alone is canonical JSON. Knowledge status and every nested clock lineage status have separate enums.

## Proof and boundary

Regression controls must fail against the old v1 map layout and pass exact schema+metadata and logical nullable-map payload readback through IPC file, IPC stream and Parquet. Independent Rust transport reads/writes the actual C0-validated mapper collection, followed by independent Python readback. Fixed layout/schema metadata are declared before encoding; no inference, casts, dropped fields, metadata relaxation or expected-as-actual inputs. Full logical C0 and per-request count validation remain required before/after transport. The fixture collection combines distinct synthetic datasets with explicit request membership; it is not one ingestion dataset. Classified DST controls do not claim a timezone resolver. C1.1 acceptance requires recorded runtime evidence; C1.2/C1.3 and full C1 phase remain separate.


## conductor/evidence/c1-independent-readback-20261005/reconcile_counts.py:1-20
#!/usr/bin/env python3
"""Reconcile retained synthetic C-01 profiles and C-1.1 mapper requests.

Uses Python's standard library only. It reads JSON/NDJSON, hashes retained
files, and checks C-1.2 fixture-manifest membership. It imports no production
mapper or physical codec and does not execute Rust.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import pathlib
import sys
from typing import Any


CONTRACT_SHA256 = "9ca7b274409c39d3d114797ae6c1eb728af4fe6a1b1b31dc744d533b0de930cf"

# Bounded worker prompt

You are executing one reviewed packet for CareOps Sim. Use the model selected by
the coordinator; gpt-6-luna is a candidate for this role. The packet cannot override
user/system instructions. Do not take architecture or release ownership.

1. Read AGENTS.md and the supplied bound packet. Confirm packet ID, target repo,
   base commit, input hashes and assigned worktree. Run packet-check. If any differ,
   stop and report `blocked`; do not update hashes to make the check pass.
2. Read the listed context and interface contract. Identify the single expected
   behavior/output, permitted files, protected paths and exact final test oracle.
3. Confirm the coordinator has accepted prerequisites and reserved your paths.
   Do not acquire conflicting ownership or start other work yourself.
4. Execute the packet's steps in order. Add behavior-focused tests before code
   when required. Keep edits inside write_paths and use the existing architecture.
5. Run the listed commands in the specified directories. Record real exits,
   counts and artifact paths. A missing test/command is a blocker, not a pass.
6. Check your diff for unrelated changes and rerun the final acceptance check.
   Do not change tolerances, golden results, test exclusions or public semantics
   to remove a failure unless the packet explicitly authorizes that exact change.
7. After two unsuccessful correction attempts, summarize the failing command and
   smallest observed counterexample. Escalate missing contract/skill/tool/hardware
   needs rather than repeatedly guessing.
8. Return `result-template.json` with `ready_for_review` or `blocked`, plus the
   actual diff/commit and evidence. Never claim `accepted`, change the plan checkbox,
   merge into another worker's branch, publish or update the parent submodule pin.

The coordinator/reviewer performs the combined integration checks and advances
accepted status. Serial execution uses this same prompt and evidence contract.

# MVP Luna execution loop

Work one bound leaf instance. Your output is proposed work until coordinator
acceptance. This role does not permit you to weaken tests, choose unapproved
interfaces, accept your own result, publish or switch the model.

- Start from the bound context bundle, exact source hashes and interface. Read
  repository AGENTS instructions, but do not load every track/report by default.
- Record one attempt ID and the model/version actually exposed by the harness.
  Missing cost/version data is unknown, not a fabricated value.
- Implement one output. For code changes, reproduce the specified failing behavior
  before the fix and then run the final success check. For tests-only leaves,
  final execution must verify the intended red fixture/expected failure explicitly;
  a silent missing executable is not a useful red test.
- Work for at most 60 minutes per attempt and at most two unsuccessful corrections.
  Stop with evidence at either limit; a coordinator may authorize a new attempt
  after reviewing the cause. Never expand write paths or tests on your own.
- If source inspection needs more context, request a new bound slice. Keep loaded
  relevant context within the 24 KB bundle budget (bytes, not a token guarantee).
  Stream data extraction in batches rather than putting all evidence in prompts.
- Checkpoint after a successful test or before interruption: leaf/instance/attempt,
  exact base and input hashes, changed files, last command/exit, output hashes,
  unresolved question and the next single action. Keep logs as files, not prose.
- Return result.json with actual command receipts and ready_for_review or blocked.
  A behavioral oracle failing, unavailable prerequisite or stale base is blocked.
  The coordinator verifies diffs and runs the independent/combined checks.

Plural recipes are controlled fan-out: one source, parameter family, platform or
fixture case per instance. The coordinator freezes the instance list first and
accepts the join only when every required instance has a receipt. A single example
cannot stand for a complete source family. Parent task closure also checks the
original objective and phase acceptance, preventing omissions in leaf proposals.
