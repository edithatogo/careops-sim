"""UNBOUND preparation template. Bind and independently review before execution."""
import datetime, hashlib, json, os, re, subprocess, sys, time
from pathlib import Path
PACKET_PATH = Path(__file__).with_name('packet.json')
TOOLCHAIN = Path('/Users/doughnut/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin')
def sha(b): return hashlib.sha256(b).hexdigest()
def require(ok, reason):
    if not ok: raise SystemExit(reason)
def new_json(p, value):
    with p.open('x') as f: json.dump(value, f, indent=2); f.write('\n')
def git(root, *argv): return subprocess.check_output(['git', *argv], cwd=root).decode().strip()
def source_hashes(root, packet): return {s:sha((root/s).read_bytes()) for s in packet['source_paths']}
def versions():
    v={n:subprocess.check_output([str(TOOLCHAIN/n),'--version']).decode().strip() for n in ('rustc','cargo','rustfmt')}
    require(v['rustc'].startswith('rustc 1.99.0 ') and v['cargo'].startswith('cargo 1.99.0 '),'Rust/Cargo1.99 required')
    return v
def binding():
    require(PACKET_PATH.is_file(),'Unbound template: no packet.json')
    packet=json.loads(PACKET_PATH.read_text());require(packet.get('status')=='prepared' and packet.get('base_commit') and packet.get('target_worktree'),'Unbound template; root binding required')
    root=Path(packet['target_worktree']); authority=json.loads(Path(packet['dispatch_authority_path']).read_text())
    require(authority['packet_sha256']==sha(PACKET_PATH.read_bytes()) and authority['driver_sha256']==sha(Path(__file__).read_bytes()) and authority['packet_path']==str(PACKET_PATH) and authority['target_worktree']==str(root) and authority['base_commit']==packet['base_commit'],'Root external authority mismatch')
    require(git(root,'rev-parse','HEAD')==packet['base_commit'] and not git(root,'status','--porcelain'),'Clean exact joined head required')
    require(all(sha((root/p).read_bytes())==h for p,h in packet['input_hashes'].items()),'Bound input drift')
    hashes=source_hashes(root,packet);require(hashes==packet['expected_source_hashes'],'Source drift')
    return packet,root,hashes

def argv_for(packet):
    packages=['-p','kairo-ecs-core','-p','kairo-ecs-des','-p','kairo-ecs-abm','-p','kairo-ecs-calibration','--features','kairo-ecs-calibration/flow']
    return {'tests':[str(TOOLCHAIN/'cargo'),'test','--locked',*packages,'--','--test-threads=1'],
        'clippy':[str(TOOLCHAIN/'cargo'),'clippy','--locked',*packages,'--all-targets','--','-D','warnings'],
        'format':[str(TOOLCHAIN/'rustfmt'),'--edition','2021','--check','--config','skip_children=true',*[p for p in packet['source_paths'] if p.endswith('.rs')]]}

def summaries(raw, packet):
    text=raw.decode(errors='replace');rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    observed=[n for n in packet['required_success_names'] if re.search(rb'test [^\n]*'+re.escape(n.encode())+rb' \.\.\. ok',raw)]
    return {'passed':sum(int(x[0]) for x in rows),'failed':sum(int(x[1]) for x in rows),'ignored':sum(int(x[2]) for x in rows),'suite_summaries':len(rows),'required_success_names_observed':observed,'missing_suite_markers':[m for m in packet['required_suite_markers'] if m.encode() not in raw]}

def history(out, root, packet, gates, tool):
    starts={p.name.removesuffix('-started.json'):p for p in out.glob('*-started.json')};ends={p.name.removesuffix('-result.json'):p for p in out.glob('*-result.json')}
    require(starts.keys()==ends.keys(),'Unmatched started/terminal receipt; reconcile')
    rows=[]
    for stem,path in ends.items():
        a=json.loads(starts[stem].read_text());b=json.loads(path.read_text());g=b['gate'];require(g in gates,'Unexpected gate')
        for k in ('gate','argv','cwd','head','packet_sha256','start','toolchain','source_hashes','log'):require(a[k]==b[k],'Receipt pair mismatch')
        require(a['status']=='started' and b['status']=='finished' and b['argv']==gates[g] and b['cwd']==str(root) and b['head']==packet['base_commit'] and b['packet_sha256']==sha(PACKET_PATH.read_bytes()) and b['toolchain']==tool,'Receipt binding mismatch')
        require(b['exit_code']!=0 or b['command_exit_code']==0,'Passing receipt requires actual command exit0')
        require(b['source_hashes']==b['source_hashes_after'] and set(b['source_hashes'])==set(packet['source_paths']),'Source changed during gate')
        require(b['started_sha256']==sha(starts[stem].read_bytes()),'Started receipt hash mismatch')
        require(str(b['log']).startswith(packet['logs_prefix']+'/'),'Log path outside scope')
        raw=(root/b['log']).read_bytes();require(sha(raw)==b['log_sha256'],'Raw log hash mismatch')
        if g=='tests':require(b['test_summary']==summaries(raw,packet),'Observed tests disagree with raw log')
        require(b['end']>=b['start'],'Invalid receipt chronology')
        rows.append({**b,'receipt_path':str(path.relative_to(root)),'receipt_sha256':sha(path.read_bytes())})
    rows.sort(key=lambda r:r['start'])
    for a,b in zip(rows,rows[1:]):require(a['end']<=b['start'],'Overlapping final gates')
    return rows

def raw_evidence(root, test, packet):
    process=(root/test['log']).parent/(Path(test['log']).stem+'-process');calls=[]
    for p in process.rglob('process-invocations.txt'):
        for b in re.split(r'\n\s*\n',p.read_text().strip()):
            if b:calls.append(dict(line.split('=',1) for line in b.splitlines()))
    require(len(calls)==26 and sorted(r['case'] for r in calls)==packet['expected_process_case_names'],'Expected exact26 inherited raw child records')
    records=[]
    for r in calls:
        f=Path(r['input_file']);f=f if f.is_absolute() else root/f;require(f.is_relative_to(process),'Child checkpoint outside declared process scope')
        require(r['child_exit_code']=='Some(0)' and sha(f.read_bytes())==r['input_sha256'],'Child failed/checkpoint mismatch')
        stdout=f.with_suffix('.child.stdout.log');stderr=f.with_suffix('.child.stderr.log');traces=re.findall(r'^C2_PORTABLE_PROCESS_TRACE:([0-9a-f]+)$',stdout.read_text(),re.M);require(len(traces)==1,'Expected one complete trace')
        require(sha(traces[0].encode())==r['actual_trace_hex_sha256'] and sha(bytes.fromhex(traces[0]))==r['expected_trace_sha256'],'Trace/raw decoded byte hash mismatch')
        records.append({'case':r['case'],'checkpoint_path':str(f.relative_to(root)),'checkpoint_sha256':sha(f.read_bytes()),'expected_trace_sha256':r['expected_trace_sha256'],'actual_trace_hex_sha256':r['actual_trace_hex_sha256'],'actual_decoded_trace_sha256':sha(bytes.fromhex(traces[0])),'trace_matches_expected':True,'child_exit_code':0,'stdout_path':str(stdout.relative_to(root)),'stdout_sha256':sha(stdout.read_bytes()),'stderr_path':str(stderr.relative_to(root)),'stderr_sha256':sha(stderr.read_bytes())})
    decoded={}
    for p in process.rglob('decoded-trace-byte-hashes.txt'):
        row={}
        for line in p.read_text().splitlines():
            k,sep,v=line.partition('=')
            if not sep:continue
            if k=='case':
                if row:require(row['case'] not in decoded,'Duplicate decoded V3 proof case');decoded[row['case']]={**row,'proof_path':str(p.relative_to(root)),'proof_sha256':sha(p.read_bytes())}
                row={'case':v}
            else:row[k]=v
        if row:require(row['case'] not in decoded,'Duplicate decoded V3 proof case');decoded[row['case']]={**row,'proof_path':str(p.relative_to(root)),'proof_sha256':sha(p.read_bytes())}
    v3=sorted(r['case'] for r in records if r['case'].startswith('portable-v3-'));require(len(v3)==4 and set(decoded)==set(v3),'Expected four decodedV3 proofs')
    proofs=[]
    by={r['case']:r for r in records}
    for case in v3:
        r=decoded[case];require(r['expected_raw_sha256']==r['actual_decoded_raw_sha256']==by[case]['expected_trace_sha256'],'DecodedV3 proof mismatch');proofs.append({**r,'match':True})
    source=(root/packet['legacy_golden_source']).read_text();block=re.search(r'const LEGACY_ENVELOPE_SHA256:.*?\n\];',source,re.S);require(block is not None,'Golden declaration absent')
    literals=dict(re.findall(r'"([^"]+)"\s*,\s*"([0-9a-f]{64})"',block.group()));require(len(literals)==19,'Expected19 literal goldens')
    golden=[]
    for case,h in literals.items():require(case in by and by[case]['checkpoint_sha256']==h,'Literal/raw envelope mismatch');golden.append({'case':case,'expected_raw_envelope_sha256':h,'actual_raw_envelope_sha256':by[case]['checkpoint_sha256'],'match':True})
    return {'expected_count':26,'verified_count':26,'case_records':records,'v3_decoded_byte_trace_records':proofs},{'expected_count':19,'verified_count':19,'raw_envelope_records':golden}

def main():
    require(len(sys.argv)==2 and sys.argv[1] in ('tests','clippy','format','finalize'),'Choose tests, clippy, format or finalize')
    action=sys.argv[1];packet,root,current=binding();gates=argv_for(packet);tool=versions();out=root/packet['logs_prefix'];out.mkdir(parents=True,exist_ok=True);rows=history(out,root,packet,gates,tool)
    if action=='finalize':
        failures=[r for r in rows if r['exit_code']!=0]
        if failures:
            new_json(root/packet['result_path'],{'status':'stopped_final_failure','head':packet['base_commit'],'gates':rows,'scope':'No acceptance; failed raw receipts preserved'});return 0
        require([r['gate'] for r in rows]==['tests','clippy','format'] and all(r['source_hashes']==current for r in rows),'Exactly three ordered passing gates at current sources required')
        require(set(packet['required_success_names'])<=set(rows[0]['test_summary']['required_success_names_observed']),'Missing required proofs')
        process,golden=raw_evidence(root,rows[0],packet)
        new_json(root/packet['result_path'],{'status':'ready_for_root_acceptance_review','packet_id':packet['packet_id'],'packet_sha256':sha(PACKET_PATH.read_bytes()),'head':packet['base_commit'],'commit':packet['base_commit'],'worktree':str(root),'toolchain':tool,'input_hashes':packet['input_hashes'],'input_hashes_verified_count':len(packet['input_hashes']),'protected_sources':current,'gates':rows,'test_summary':rows[0]['test_summary'],'process_evidence':process,'legacy_golden_parity':golden,'scope':'Combined native only; no persistence/pin/ED acceptance'});return 0
    require(not any(r['exit_code']!=0 for r in rows),'A final gate failed; no rerun or correction in this packet')
    order=['tests','clippy','format'];require(len(rows)<3 and action==order[len(rows)] and all(r['source_hashes']==current for r in rows),'Wrong gate order or source drift')
    stem=f'{action}-{time.time_ns()}-{os.getpid()}';log=out/(stem+'.log');started=out/(stem+'-started.json')
    row={'gate':action,'argv':gates[action],'cwd':str(root),'head':packet['base_commit'],'packet_sha256':sha(PACKET_PATH.read_bytes()),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'toolchain':tool,'source_hashes':current,'log':str(log.relative_to(root)),'status':'started'};new_json(started,row)
    env=dict(os.environ);env.update(PATH=str(TOOLCHAIN)+os.pathsep+env.get('PATH',''),PYTHONDONTWRITEBYTECODE='1',CARGO_HOME='/tmp/c2-route-receipt-cargo-home',CARGO_TARGET_DIR=str(out/'target'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0');env['KAIRO_C2_PROCESS_ARTIFACT_DIR']=str(out/(stem+'-process'))
    with log.open('x') as f:actual=subprocess.run(gates[action],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
    raw=log.read_bytes();after=source_hashes(root,packet);code=actual;error=None;summary=summaries(raw,packet) if action=='tests' else None
    if after!=current:code=2;error='Source changed during final gate'
    if action=='tests' and actual==0 and (set(summary['required_success_names_observed'])!=set(packet['required_success_names']) or summary['failed'] or summary['missing_suite_markers']):code=2;error='Missing required proofs or failed test summary'
    try:binding()
    except SystemExit:code=2;error='Post-gate binding integrity failure'
    row.update(status='finished',end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=code,command_exit_code=actual,source_hashes_after=after,log_sha256=sha(raw),started_sha256=sha(started.read_bytes()),test_summary=summary,gate_error=error);terminal=out/(stem+'-result.json');new_json(terminal,row);print(json.dumps({'exit_code':code,'receipt_path':str(terminal.relative_to(root)),'log_sha256':row['log_sha256']}));return code
if __name__=='__main__':raise SystemExit(main())
