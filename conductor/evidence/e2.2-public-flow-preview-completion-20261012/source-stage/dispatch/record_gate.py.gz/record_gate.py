"""Three-command source-stage receipt driver for the reviewed Flow preview packet."""
import datetime, hashlib, json, os, re, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
ART = ROOT / '.artifacts/e22-public-flow-preview-20261012'
PACKET_PATH = ART / 'dispatch/packet.json'
TOOLCHAIN = Path('/Users/doughnut/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin')
OWNED = ['crates/kairo-ecs-des/src/flow.rs', 'crates/kairo-ecs-des/tests/flow_preview_v1.rs', 'conductor/design/des/e2-flow-preview-v1.md']
REQUIRED = ['flow_preview_empty','flow_preview_ordered_live_head','flow_preview_cancelled_head_preserves_logical_state','flow_preview_deferred_disabled_flush','flow_preview_live_stale_completion','flow_preview_budget_halted','flow_preview_horizon']
GATES = {
 'clippy': [str(TOOLCHAIN/'cargo'),'clippy','--locked','-p','kairo-ecs-des','--all-targets','--','-D','warnings'],
 'focused': [str(TOOLCHAIN/'cargo'),'test','--locked','-p','kairo-ecs-des','flow_preview_','--','--test-threads=1'],
 'format': [str(TOOLCHAIN/'rustfmt'),'--edition','2021','--check','--config','skip_children=true',OWNED[0],OWNED[1]],
}
def h(b): return hashlib.sha256(b).hexdigest()
def hashes(): return {p:(h((ROOT/p).read_bytes()) if (ROOT/p).is_file() else None) for p in OWNED}
def write_new(path, value):
 with path.open('x',encoding='utf-8') as f: json.dump(value,f,indent=2); f.write('\n')
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode: raise SystemExit('git receipt check failed')
 return p.stdout.strip()
def main():
 if len(sys.argv)!=2 or sys.argv[1] not in GATES: raise SystemExit('choose clippy, focused, or format')
 gate=sys.argv[1]; packet=json.loads(PACKET_PATH.read_text())
 if git('rev-parse','HEAD')!=packet['base_commit']: raise SystemExit('frozen HEAD drift; stop')
 if git('status','--porcelain'): 
  # Source edits and this declared artifact prefix are expected; reject every other changed path.
  changed=set(filter(None,git('diff','--name-only','-z','HEAD').split('\x00')))
  untracked=set(filter(None,git('ls-files','--others','--exclude-standard','-z').split('\x00')))
  allowed=set(OWNED)
  allowed |= {p for p in changed|untracked if p==str(ART.relative_to(ROOT))+'/result.json' or p.startswith(str(ART.relative_to(ROOT))+'/logs/')}
  if (changed|untracked)-allowed: raise SystemExit('out-of-scope source change; stop')
 for path, expected in packet['input_hashes'].items():
  if path in OWNED: continue
  p=ROOT/path
  if not p.is_file() or h(p.read_bytes())!=expected: raise SystemExit('bound input drift; stop')
 if any(not (ROOT/p).is_file() for p in OWNED): raise SystemExit('all three owned source files must exist before gates')
 out=ART/'logs'; out.mkdir(parents=True,exist_ok=True)
 failed=0
 for receipt in out.glob('*-result.json'):
  try:
   row=json.loads(receipt.read_text())
   failed += int(row.get('status')=='finished' and row.get('exit_code')!=0)
  except (ValueError,OSError): raise SystemExit('unreadable prior receipt; stop')
 if failed>=packet['development_failure_limit']: raise SystemExit('three failed development executions reached; stop')
 versions={name:subprocess.run([str(TOOLCHAIN/name),'--version'],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for name in ('rustc','cargo')}
 if any(p.returncode or not p.stdout.startswith(name+' 1.99.0 ') for name,p in versions.items()): raise SystemExit('Rust/Cargo 1.99.0 unavailable; stop')
 stem=f'{gate}-{time.time_ns()}-{os.getpid()}'; log=out/(stem+'.log')
 record={'gate':gate,'argv':GATES[gate],'cwd':str(ROOT),'head':git('rev-parse','HEAD'),'packet_sha256':h(PACKET_PATH.read_bytes()),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'toolchain':{k:p.stdout.strip() for k,p in versions.items()},'source_hashes':hashes(),'log':str(log.relative_to(ROOT)),'status':'started'}
 write_new(out/(stem+'-started.json'),record)
 env=dict(os.environ); env.update(PATH=str(TOOLCHAIN)+os.pathsep+env.get('PATH',''),PYTHONDONTWRITEBYTECODE='1',CARGO_HOME='/tmp/c2-route-receipt-cargo-home',CARGO_TARGET_DIR=str(out/'target'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
 with log.open('x',encoding='utf-8') as stream: command_exit=subprocess.run(GATES[gate],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
 content=log.read_bytes(); exit_code=command_exit; error=None
 if gate=='focused' and exit_code==0:
  missing=[name for name in REQUIRED if not re.search(rb'test [^\n]*'+name.encode()+rb' \.\.\. ok',content)]
  if missing: exit_code=2; error='Missing successful required focused tests: '+','.join(missing)
 after=hashes()
 if after!=record['source_hashes']: exit_code=2; error='Owned source changed during captured command'
 record.update(status='finished',end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=exit_code,command_exit_code=command_exit,gate_error=error,log_sha256=h(content),source_hashes_after=after)
 result=out/(stem+'-result.json'); write_new(result,record)
 print(json.dumps({'gate':gate,'exit_code':exit_code,'receipt':str(result.relative_to(ROOT)),'log':record['log']}))
 return exit_code
if __name__=='__main__': raise SystemExit(main())
