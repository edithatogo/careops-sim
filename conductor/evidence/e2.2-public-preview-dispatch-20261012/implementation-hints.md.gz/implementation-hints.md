# Public Flow preview implementation hints

Examined docs head `5fc5fe129c0b1b6a57311b377441ffeb72a51123` in `/Users/doughnut/Documents/careops-sim-session-worktrees/kairos-e22-public-flow-preview-20261012`. Read-only preparation; root-bound packet and its hashes govern execution. Copy narrowly into owned test files; do not modify referenced helpers.

## Method and ordering

`crates/kairo-ecs-des/src/flow.rs:3` already imports `ScheduledEventPreview`. Insert the exact one-line delegation next to `now` around line1537. Core's existing `peek_next(&mut self)` is at `crates/kairo-ecs-core/src/lib.rs:119`; copied preview fields are at line40. Do not call `check_running` or `halt_error`. Time/priority/sequence are the ordering tuple; compare the exact event IDs returned by scheduling to actual dispatches. Submit builder `.scheduler_priority(i32)` differs from queue `.priority(i32)`; use the former to control scheduler ordering.

## Small public fixture and complete state

`crates/kairo-ecs-des/tests/flow_deferred_allocation_v1.rs:11` has `t(u128)->SimTime`, `step(&mut FlowRuntime)->FlowDispatch`, and `has_transition` at21. Its `acquire_work` at43 is reusable. Adapt only required helpers. `create_resource_with_allocation_mode(1, Deferred)` and `create_work(owner, SimDuration::from_ticks(...), registration, context)` are actual APIs.

For external complete-state preservation, use `capture_checkpoint_image(&codecs, FlowCheckpointLimits::default())` and `budget_snapshot()` before/after preview. Match `FlowCheckpointImage::V3` to inspect raw `builtins.work_progress` rows; public `work_progress()` is clock-derived and may change across dispatch time. The image's scheduler entries include `live`, so comparisons inspect real native state rather than detached DTO fixtures.

Minimal codecs: copy u64 encoder/decoder signatures from `crates/kairo-ecs-des/tests/flow_checkpoint_v3.rs:18,26`; decoder takes `&FlowCheckpointRebindV1`, not a size argument. Register the matching context under the exact runtime registration string. If source uses `register_work_handlers(..., WorkHandlers::default())`, codec manifest must ALSO register matching default handlers with `FlowHandlerCodeIds::default()`; context+continuation alone is insufficient (recent portable failure). If no runtime handler registration exists, do not add a mismatched codec handler manifest. Reference minimal `codecs()` at41, or callback-enabled codecs in calibration below. Fixed codecs need no calibration seed/provider.

## Deferred and halted proofs

`flow_deferred_allocation_v1.rs:61` demonstrates queued Submit with no grant until explicit Flush; `:218` covers disabled gating; `:1000` has a genuine budget1 precommit halt. Adapt the halt to capture and compare complete V3 images after BOTH first and repeated error, not merely budget/next tick. Pending Flush at0 should remain previewable and repeated step must preserve exact `SameTickBudgetExceeded { at_ticks:0, limit:1 }`.

To avoid borrow conflicts, capture `let now = flow.now()` before passing `&mut flow` to helpers or scheduling methods. Assertion helpers should assert semantic dispatch errors are absent; budget-halt proof explicitly expects the error instead.

## Actual LIVE stale11 / useful14

Shortest existing fixture is `crates/kairo-ecs-calibration/src/c5_native.rs:619` (`stale_completion_runtime`) or `shadow_native.rs:572` (`stale_shadow_preview_world`). These are private calibration test helpers: COPY the public Flow construction into the new owned DES test, do not import them or edit calibration. Low work10 starts1 with Deferred Flush1; urgent work2 preempts at4 with Flush4; urgent completes6; explicit readmission Flush7 resumes low. Old completion11 stays LIVE, useful completion becomes14. Bounded drain helpers assert expected ticks/events and panic on exhaustion.

The updated C5 helper uses active completion callbacks and codec registrations. Shadow callback `count_preview_completion` at435 has signature `fn(&mut u32, &FlowCallbackSnapshot, &mut FlowCommandSink)` and increments the context. Native `FlowContinuations` receives the callback; codec `FlowContinuationCodeIds` receives matching stable ID/version. Exercise an actual useful completion baseline before asserting no stale callback. Check raw stored low progress before/after stale dispatch11 plus empty lifecycle and callback batches. Inspected useful_elapsed7 and remaining3 at11 are expected. Preview must return11 rather than skip directly to14.

`crates/kairo-ecs-des/tests/flow_checkpoint_v3.rs:634` shows selecting stale Completion by request+due11 and verifying the scheduler row is LIVE. Do not choose the first Completion event by ID. Native mixed fixture at472 is richer and longer; no need to copy its continuation-readiness scenario just to establish this simple preview proof.

## Inline tombstone proof

Flow has no public event-cancel API. Keep this one proof inside `flow.rs`'s existing test module. Use an actual `FlowRuntime` and private `schedule(Command::Capacity(resource, ...), time)` (or existing scheduler scheduling with a matching command map). Cancel the head via private scheduler.cancel(event), remove that command test-side, and leave a distinct later live capacity event. Capacity commands avoid grant-boundary/Flush indexes that would need test-side cleanup. Snapshot private scheduler.stats, live-entry membership, resource snapshot and world/request state after cancellation but before preview. Only dead heap rows may disappear. Assert exact next live event and unchanged logical snapshots, repeated preview. Do not assert raw heap byte equality or add a public stats/test hook.

## Proof order and compile pitfalls

Build minimal helpers then empty, ordered head, horizon, Deferred/disabled, halt, stale callback, inline tombstone tests. Keep all seven contract names exactly `flow_preview_*`; filtered cargo test reaches both library inline and integration cases. New external file must import public IDs; `ResourceId`, `WorkId` and `RequestId` wrap private EntityId fields, so retain returned handles instead of constructing them. Work IDs differ from actor EntityId; DomainControl expects work. Native image row collections are vectors with typed row values; avoid guessing reference depth. Preserve `u128` tick/duration types and `NonZeroU64` budget.

Format owned files BEFORE captured gates, then targeted DES all-target strict Clippy, focused proofs, owned format at identical final hashes. At most three failed development executions total; retain every receipt, fix only bounded source issues, stop at ceiling or shared/API need. No full joined suite in source stage; root later qualifies clean integration. No repository mutation or test execution occurred in preparing these hints.
