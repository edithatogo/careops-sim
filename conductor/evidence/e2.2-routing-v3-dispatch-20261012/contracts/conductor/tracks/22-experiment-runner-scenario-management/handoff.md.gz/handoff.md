# Handoff: Track 22 Experiment Runner & Scenario Management

Last updated: 2026-05-11

## Summary

Captured the scenario-management story so other tracks can assume named runs,
replay inputs, documented output shape, and a concrete replay comparison flow.
The GNU-toolchain runtime smoke now executes the CLI commands and produces the
expected local output shape.

## Files changed

`scenarios/manifest-index.json`, `docs/scenarios/factory-bottleneck-run-replay.md`, `docs/cli/kairo-ecs-cli.md`, `scripts/scenarios/validate-track22-smoke.ps1`, `conductor/tracks/22-experiment-runner-scenario-management/test-matrix.md`, `conductor/tracks/22-experiment-runner-scenario-management/risk-register.md`, `conductor/tracks/22-experiment-runner-scenario-management/handoff.md`

## Contracts consumed

`conformance/fixtures/manifest.json`, `conformance/fixtures/vvuq_scenario_replay.json`, `conformance/fixtures/deterministic_ordering.json`, `examples/experiments/factory_bottleneck_v1.scenario.toml`, `examples/experiments/factory_bottleneck_v1.seeds.toml`, `conductor/workflow.md`

## Release gates affected

Scenario replay and determinism checks now feed the reproducibility and release gate surface.

## Concrete runner note

- Scenario index: `scenarios/manifest-index.json`.
- Scenario manifest: `examples/experiments/factory_bottleneck_v1.scenario.toml`.
- Seed manifest: `examples/experiments/factory_bottleneck_v1.seeds.toml`.
- Replay command: `cargo run -p kairo-ecs-cli -- replay --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml --output target/kairo-ecs-smoke/factory_bottleneck_v1`.
- Output shape: `manifest.json`, `summary.json`, `replay-comparison.json`, `resumability-plan.json`.
- Comparison flow: load manifest and seeds, replay the fixture, compare emitted trace and summary metrics, emit a drift report.
- Real fixture references: `vvuq_scenario_replay_v1` and `scheduler_ordering_v1` from `conformance/fixtures/manifest.json`.

## Scenario manifest/run/replay note

`docs/scenarios/factory-bottleneck-run-replay.md` now records the first usable
Track 22 scenario smoke target, while `docs/cli/kairo-ecs-cli.md` provides the
matching command reference and quickstart:

- Scenario ID: `factory_bottleneck_v1`.
- Replay fixture: `vvuq_scenario_replay_v1`.
- Execution fixture: `scheduler_ordering_v1`.
- Comparison basis: `expected_kind_order`.
- Expected event kind order: `1,2,4,3`.
- Expected summary hash: `1d53b73b244a84de`.
- Claim boundary: verification smoke only; not a real-world validation or
  uncertainty claim.

## R2 local implementation slice

Added the first concrete Track 22 runner surface in `crates/kairo-ecs-cli/`:

- `validate-scenario --scenario <path> --seed-manifest <path>`
- `replay --scenario <path> --seed-manifest <path> --output <dir>`
- `resume-plan --scenario <path> --output <dir>`

The R2 slice intentionally supports only the committed
`factory_bottleneck_v1` smoke scenario and `scheduler_ordering_v1` replay
fixture. It writes the expected local output shape:

- `manifest.json`
- `summary.json`
- `replay-comparison.json`
- `resumability-plan.json`

Validation evidence:

```bash
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/scenarios/validate-track22-smoke.ps1
cargo check -p kairo-ecs-cli
node tests/conformance/conformance-check.mjs
cargo run -p kairo-ecs-cli -- validate-scenario --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml
```

- PASS: `validate-track22-smoke.ps1` returned `status: ok` for
  `factory_bottleneck_v1`, `vvuq_scenario_replay_v1`, `scheduler_ordering_v1`,
  expected kind order `1,2,4,3`, and expected summary hash
  `1d53b73b244a84de`.
- PASS: `cargo check -p kairo-ecs-cli` completed in the dev profile.
- PASS: `node tests/conformance/conformance-check.mjs` validated four ready
  fixtures, including `vvuq_scenario_replay_v1`.
- PASS: `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- validate-scenario --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml` returned `status: ok` for `factory_bottleneck_v1` and fixture `scheduler_ordering_v1`.
- PASS: `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- replay --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml --output target/kairo-ecs-smoke/factory_bottleneck_v1` returned `status: ok`, output `target/kairo-ecs-smoke/factory_bottleneck_v1`, and summary hash `1d53b73b244a84de`.
- PASS: `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- resume-plan --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --output target/kairo-ecs-smoke/factory_bottleneck_v1` returned `status: ok` and `checkpoint_every_events: 2`.

The new CLI docs page stays intentionally narrow: it documents the implemented
smoke commands, reserves `run`/`collect`/`analyze` for the fuller runner
surface, and points readers at the local smoke validator.

## Risks and unresolved questions

The main risk is that a runner can look deterministic in one environment and drift in another if the scenario inputs are not pinned.

## Contracts changed

Track 22 now documents the implemented smoke-command surface for `validate-scenario`, `replay`, and `resume-plan`, with `factory_bottleneck_v1` as the only claimed scenario target.

## Tests added

The current evidence is `scripts/scenarios/validate-track22-smoke.ps1`,
`cargo check -p kairo-ecs-cli`, `node tests/conformance/conformance-check.mjs`,
and the GNU-toolchain runtime smoke commands listed above.

## Known risks

Scenario replay drift remains the main track risk. The local shell can now
provide executable CLI replay evidence through the GNU toolchain, but the MSVC
path remains unreliable on this host.

## Follow-up issues

Fix the local Windows linker path, then rerun the `validate-scenario`, `replay`, and `resume-plan` commands. Broaden the runner beyond the committed smoke scenario only after the parser and resumability tests have real coverage.

## Integration notes

Tracks 21, 28, and release planning may consume only the smoke evidence named here; they should not treat it as quantified uncertainty evidence or production experiment-runner readiness.
## Phase closeout evidence

2026-05-11 implementation/review pass:

- `$conductor-review` finding: the implemented scenario smoke slice is now
  backed by executable GNU-toolchain replay and resumability commands for the
  committed `factory_bottleneck_v1` / `scheduler_ordering_v1` smoke target.
- Accepted fixes: retained the narrow smoke-scenario boundary, documented the
  expected local output shape, and updated the track status mirrors to `Done`.
- Validation commands passed: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/scenarios/validate-track22-smoke.ps1`, `node tests/conformance/conformance-check.mjs`, `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- validate-scenario --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml`, `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- replay --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --seed-manifest examples/experiments/factory_bottleneck_v1.seeds.toml --output target/kairo-ecs-smoke/factory_bottleneck_v1`, and `cargo +stable-x86_64-pc-windows-gnu run -p kairo-ecs-cli -- resume-plan --scenario examples/experiments/factory_bottleneck_v1.scenario.toml --output target/kairo-ecs-smoke/factory_bottleneck_v1`.
- Cleanup state: no generated artifacts were retained beyond the smoke output
  directory under `target/`.
- commit SHA: `e2824b36ff816fca1189ca1846bc28cfe26782db`
- pushed ref: `origin/conductor-close-reviewed-tracks-20260510`
- `validate_conductor_git_closeout.ps1 -RequireCleanWorkingTree`: passed after
  the closeout commit was recorded and pushed.
- next-phase decision: Track 22 is `Done`; keep resumability and production
  runner claims bounded to the committed smoke scenario until broader runner
  coverage exists.

## Track 39 CLI handoff approval -- 2026-05-18

Track 22 remains the owner of `crates/kairo-ecs-cli/`. The minimal `run`,
`checkpoint`, and `resume` commands currently present in
`crates/kairo-ecs-cli/src/main.rs` are accepted as a Track 22 handoff surface for
Track 39 wrapper compatibility only:

- `run --scenario ... --output ...` may either execute the existing
  Track 22 smoke replay path when a seed manifest is supplied or capture a
  runner request when no seed manifest is supplied.
- `checkpoint --output ...` writes a scaffold checkpoint manifest for
  interruption-path validation.
- `resume --checkpoint ... --output ...` validates the checkpoint path and
  writes a scaffold resume request.

This approval does not promote Track 39 to owner of the experiment-runner CLI,
does not add production resumability evidence, and does not change the broader
Track 22 boundary: real experiment execution, checkpoint state semantics,
resume semantics, `collect`, and `analyze` remain Track 22 follow-up work.


## C2 portable state foundation — 2026-10-09

ADR-0016 defines owner-derived full-state capture/import rather than fixed-recipe
replay. Native component source `e5a130223fad6148dabea2379f767514bd1eaeb3` integrates
independently reviewed scheduler, entity allocator and calibration seed registry
images. Core/state expose doc-hidden Rust-only native DTO seams; no engine byte
codec/serde dependency, public FFI contract or scheduler/RNG/allocator algorithm
changed. All physical scheduler entries and live/cancelled membership/counters,
world slot generations/free LIFO/dense order, and every seed logical identity and
purpose are preserved. Limits and invariants validate before destination state
construction; allocator validation is linear with bounded scratch.

Rust1.99-only combined core/state/DES/ABM/calibration flow qualification:527 passed,
zero failed,five ignored/54 groups; strict five-package Clippy and workspace format
pass. Worker failures/corrections remain retained in the parent evidence. This is
component acceptance, not complete portable checkpoint or phase acceptance.

Dependency handoff: Track01 supplies scheduler/entity state; Track03 must add full
Flow/components and approved context/handler codecs; Track21 must integrate policy,
providers, streams and bridge state; Track22 owns the outer durable envelope,
coherent frontier, fresh-runtime identity rebinding, commit/recovery and runner
ledger. Full C2 legal modes/progress states remain the required outcome. Unknown
extension state fails closed; no silent state loss or frozen-recipe substitution.
C5 worker/candidate crash equivalence, stable API/release and clinical gates remain
separate required evidence. No track completion or upstream acceptance ledger is
changed by this experimental handoff.

## C3 scoped synthetic implementation — hosted qualification 2026-10-10

Experimental/private C3 source `faeb8e97d3021080c2dd60f0e2f065607e7666e7` passes
local and hosted Rust 1.99.0 gates, including native isolated Flow/C2 probes,
observed source preservation, bounded recovery, exact process/image readback and
physical IPC/Parquet records. Native run38047961900 passed on Ubuntu x86_64 and
macOS aarch64; PR244 has 47 successful checks and two declared conditional skips.
[Hosted evidence](../../evidence/c3-hosted-qualification-20261010/README.md) supplements the earlier local record and supersedes its
hosted-pending status for this tested source. Parent pin/phase acceptance awaits
this documentation successor's final checks. Historical owner status scopes,
C5, public API, empirical/clinical, ED MVP and release gates remain separate.

## C5 scoped supplement — 11 October 2026

Experimental synthetic study/CLI/CPU recovery source15d3ab0 is reviewed locally.
See [C5 executed evidence and limitations](../../evidence/c5-local-qualification-20261011/README.md)
and [ADR-0022](../../design/calibration/ADR-0022-c5-study-runner.md).
Historical Done and stable public API/release scopes are unchanged. Parent C5
acceptance requires successor hosted gates and independent artifact readback.


## E2 V3 routing cross-track handoff - 12 October 2026

Coordinator-authorized preparation under the full CareOps delivery goal. Accepted
explicit native V3 commit is `0813991b6dddb11635b790a9eb065651b85dd238`;
explicit wire core is `3eae7b741d9957d651883bda646aead18961c220`, with public
wire qualification joined at `81f889f66969c27048a8d23a58b47c5a75132807`.
Parent acceptance is `ef0ddc8d4c70e6f0926f45a681e6f728cbc69ab8`. These accept
explicit APIs only. Routing implementation requires the separately accepted
routing contract, reviewed hash-bound source packet and narrow claim.

The atomic routing change owns exactly these eight Rust paths (plus its separately
bound result/log outputs):

- `crates/kairo-ecs-des/src/flow/checkpoint.rs`
- `crates/kairo-ecs-des/src/flow/checkpoint/v2.rs`
- `crates/kairo-ecs-des/src/flow/checkpoint/wire.rs`
- `crates/kairo-ecs-calibration/src/flow_bridge/checkpoint_wire.rs`
- `crates/kairo-ecs-calibration/src/c2_portable_checkpoint/process_tests.rs`
- New `crates/kairo-ecs-des/tests/flow_checkpoint_routing_v3.rs`
- `crates/kairo-ecs-des/tests/flow_checkpoint_v3.rs` (narrow common-route assertion update only)
- `crates/kairo-ecs-des/tests/flow_deferred_allocation_v1.rs` (narrow common-route assertion update only)

The shared borrowed command stream becomes the complete, allocation-free
`Iterator<Item = (EventId, FlowCommandV3)>`, retaining event IDs, ordering,
AllocationFlush and live stale Completion commands. No variant filtering, V3
projection, capture retry/fallback, runtime mutation or duplicate codec invocation
is permitted. Preserve legacy V1/V2 bounds, validation/error precedence and exact
bytes, including the nonempty restart-registration boundary and old envelope
goldens. Both handoff files must be input-hash bound in the future source packet.

Track22 acknowledges consumption of Track03's complete versioned checkpoint
view and the bounded common-match migration above. Existing coherent-cut and
portable envelope checks retain their full-state validation. Compilation and
explicit wire fixtures do not establish V3 coherent or portable/resume behavior.

After routing acceptance, Track22 consumer qualification uses separate bounded
packets: coherent inline proofs in `flow_bridge.rs`, portable continuation in
`c2_portable_checkpoint.rs` and nested `process_tests.rs`; preview uses its own
`shadow_native.rs`/`c5_native.rs` lane. These may run in parallel on the same
accepted base with disjoint claims. Root joins and qualifies all consumers before
updating the parent Kairos pin and beginning the complete ED runtime bindings.

Compatibility correction: the two existing legacy-capture tests have three
common-router assertions that currently reject Deferred state. Update only those
to positive V3 routing controls while retaining every explicit V1/V2 rejection
and zero-codec assertion before successful routing. Keep exact mode/Flush and
positive codec counts; preserve test names and all true legacy goldens. The
eight-Rust-path scope supersedes the initial six-path proposal for this reason.
